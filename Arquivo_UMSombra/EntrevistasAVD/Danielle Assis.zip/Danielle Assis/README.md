Arquivo da Entrevista a Deborah Perrota de Andrade (por Danielle Assis)
Esta pasta é composta por 9 elementos:

Readme

Roteiro entrevista
Roteiro norteador para realização da entrevista.

Entrevista UMinho-20240403_140957-Gravação de Reunião
Gravação da entrevista realizada em 03/04/2024 na íntegra.

Entrevista UMinho-20240403_140957-Gravação de Reunião (transcript).mp4.pdf
Transcrição da entrevista realizada com a ferramenta Pinpoint da Google.

Entrevistaeditado
Primeiro tratamento de edição da transcrição da entrevista com formatação, correções de ortografia, pontuação, coerência textual e afins.

Entrevista_etiquetado.py
Versão da entrevista transcrita e tratada no VS CODE.

Entrevista_etiquetado.md
Versão final da entrevista tratada em .md.

Apresentação_entrevista
Apresentação sobre a experiência e resultados da atividade.
